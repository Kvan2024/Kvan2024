package com.techelevator;

import java.util.Scanner;

public class Tutorial {

    public static void main(String[] args) {

        // ***********  Step 1: Use the *new* operator to create Strings on the Heap  *************





        // ***********  Step 2: Try out some String methods  *************





        // ***********  Step 3: Compare Strings  *************





    }
}
