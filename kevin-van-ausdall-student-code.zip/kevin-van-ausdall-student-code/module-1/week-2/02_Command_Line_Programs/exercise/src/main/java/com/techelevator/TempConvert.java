package com.techelevator;

import java.util.Scanner;

public class TempConvert {

	public static void main(String[] args) {

		int outputTemp = 0;
		Scanner userTemp = new Scanner(System.in);
		System.out.println("Please enter the temperature: ");
		int startingTemp = Integer.parseInt(userTemp.nextLine());
		System.out.println("Is the temperature in (C)elsius, or (F)ahrenheit? ");
		String tempVersion = userTemp.nextLine();
		String outputVersion = "F";
		if (tempVersion.equals("F") || tempVersion.equals("f")) {
			outputVersion = "C";
		}

		if (tempVersion.equals("F") || tempVersion.equals("f")) {
			outputTemp = (int) ((startingTemp - 32) / 1.8);
			System.out.println(startingTemp + tempVersion + " is " + outputTemp + outputVersion);
		} else {
			outputTemp = (int) ((startingTemp * 1.8) + 32);
			System.out.println(startingTemp + tempVersion + " is " + outputTemp + outputVersion);
		}
	}
}