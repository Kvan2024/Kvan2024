package com.techelevator;

import java.sql.SQLOutput;
import java.util.Scanner;

public class LinearConvert {

	public static void main(String[] args) {

		int outputLength = 0;

		Scanner userTemp = new Scanner(System.in);

		System.out.println("Please enter the length: ");
		int startingLength = Integer.parseInt(userTemp.nextLine());

		System.out.println("Is the measurement in (m)eters, or (f)eet? ");
		String lengthVersion = userTemp.nextLine();

		String outputLengthVersion = "f";

		if (lengthVersion.equals("F") || lengthVersion.equals("f")) {
			outputLengthVersion = "m";
		}

		if (lengthVersion.equals("F") || lengthVersion.equals("f")) {
			outputLength = (int)(startingLength * 0.3048);
			System.out.println(startingLength + lengthVersion + " is " + outputLength + outputLengthVersion);
		}
		else {
			outputLength = (int)(startingLength * 3.2808399);
			System.out.println(startingLength + lengthVersion + " is " + outputLength + outputLengthVersion);
		}
	}

}
