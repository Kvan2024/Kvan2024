package com.techelevator;

import java.sql.SQLOutput;
import java.util.Scanner;

public class DecimalToBinary {

	public static void main(String[] args) {

		Scanner numericInput = new Scanner(System.in);

		System.out.println("Please enter a number to convert to binary: ");

		String[] userInput = numericInput.nextLine().split(" ");

		for (int x = 0; x < userInput.length; x++) {
			int numEntry = Integer.parseInt(userInput[x]);
			String binaryValue;
			if (numEntry % 2 == 0) {
				binaryValue = "0";
				numEntry = numEntry / 2;
			} else {
				binaryValue = "1";
				numEntry = numEntry / 2;
			}

			while (numEntry > 0) {
				if ((numEntry % 2) == 0) {
					binaryValue = "0" + binaryValue;
					numEntry = numEntry / 2;
				} else {
					binaryValue = "1" + binaryValue;
					numEntry = numEntry / 2;
				}
			}
			System.out.println(userInput[x] + " in binary is " + binaryValue);

		}

	}
}