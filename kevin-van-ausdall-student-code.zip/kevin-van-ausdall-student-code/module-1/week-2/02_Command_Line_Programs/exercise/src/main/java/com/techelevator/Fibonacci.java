package com.techelevator;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {

		Scanner userInput = new Scanner(System.in);
		System.out.println("Please enter a number: ");
		int fibNum = userInput.nextInt();
		int mainNum = 0;
		int secondNum = 1;
		int thirdNum = 0;

		if (fibNum <= 0) {
			System.out.println(mainNum + ", " + secondNum);
		}
		else {

			while (mainNum <= fibNum) {
				if (secondNum > fibNum) {
					System.out.print(mainNum);
				} else {
					System.out.print(mainNum + ", ");
				}
				thirdNum = mainNum + secondNum;
				mainNum = secondNum;
				secondNum = thirdNum;
			}
		}
	}
}
