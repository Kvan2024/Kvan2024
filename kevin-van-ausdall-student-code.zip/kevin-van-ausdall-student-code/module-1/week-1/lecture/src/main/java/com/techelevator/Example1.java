package com.techelevator;

public class Example1 {

	public static void main(String[] args) {

		/*
		1. What is 5 divided by 2?
		*/


		/*
		2. What is 5.0 divided by 2? (Or 5 divided by 2.0?)
		*/


		/*
		3. What is 66.6 divided by 100?
		*/
		

		/*
		4. If I divide 5 by 2, what's my remainder?
		*/
		

		/*
		5. What is 1,000,000,000 * 3?
		*/

		
	}
}
