package com.techelevator.solution;

public class Solution {

	private String id;
	private String code;
	
	public Solution(String id, String code) {
		this.id = id;
		this.code = code;
	}
	
	public String getID() {
		return this.id;
	}
	
	public String getCode() {
		return this.code;
	}
}
