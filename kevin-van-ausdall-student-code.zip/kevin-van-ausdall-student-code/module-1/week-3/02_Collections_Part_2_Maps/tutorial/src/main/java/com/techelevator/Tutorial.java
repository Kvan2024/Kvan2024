package com.techelevator;

import java.util.HashMap;
import java.util.Map;

public class Tutorial {
	

    public static void main(String[] args) {

        // Step One: Declare a Map

    	
    	// Step Two: Add items to a Map

    	
    	// Step Three: Loop through a Map

    }

}
