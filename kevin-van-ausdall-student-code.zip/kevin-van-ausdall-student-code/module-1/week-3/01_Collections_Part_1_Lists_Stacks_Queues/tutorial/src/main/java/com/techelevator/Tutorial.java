package com.techelevator;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;

public class Tutorial {
	
    public static void main(String[] args) {

    	// Step One: Declare a List

    	
    	// Step Two: Add values to a List

    	
    	// Step Three: Looping through a List in a for loop

    	
    	// Step Four: Remove an item

    	
    	// Step Five: Looping through List in a for-each loop

    }

}
