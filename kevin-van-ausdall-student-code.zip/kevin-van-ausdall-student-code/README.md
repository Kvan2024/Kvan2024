# README



## Copyright

Per the Acknowledgment of Liability Intellectual Property Ownership Agreement, all materials, lectures, and exercises delivered by Tech Elevator are solely owned by Tech Elevator, and you make no claim to any right to distribute or profit from the content herein. Tech Elevator retains all rights, title and interest in and to all related information, content, data, exams, materials, software, and all copyrights, patent rights, trademark rights and other proprietary rights therein. All rights not expressly granted by Tech Elevator to you are expressly reserved to Tech Elevator.