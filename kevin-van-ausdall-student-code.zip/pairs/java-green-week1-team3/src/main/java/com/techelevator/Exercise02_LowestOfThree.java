package com.techelevator;

public class Exercise02_LowestOfThree {

    /*
     Given three integer values, return the lowest value.

     Note: a value may be considered lower if it is less than or equal to the other value.

     lowestOfThree(1, 3, 2) → 1
     lowestOfThree(77, 45, 19) → 19
     lowestOfThree(-119, 35, 102) → -119
     lowestOfThree(63, 63, 63) → 63
     */
    public int lowestOfThree(int a, int b, int c) {

        if (a <= b && a <= c) {
            return a;
        } else if (b <= a && b <= c) {
            return b;
        } else {
            return c;
        }
    }
}
