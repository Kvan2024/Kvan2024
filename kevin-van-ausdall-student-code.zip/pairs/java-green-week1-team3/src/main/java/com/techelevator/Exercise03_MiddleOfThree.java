package com.techelevator;

public class Exercise03_MiddleOfThree {

    /*
     Given three integer values, return the middle value.

     middleOfThree(1, 3, 2) → 2
     middleOfThree(45, 45, 77) → 45
     middleOfThree(-119, 35, 102) → 35
     middleOfThree(63, 63, 63) → 63
     */
    public int middleOfThree(int a, int b, int c) {
        if (a >= b && a <= c) {
            return a;
            }
            else if (b >= c && b <= a) {
            return b;
        }
            else {
                return c;
        }
    }
}
