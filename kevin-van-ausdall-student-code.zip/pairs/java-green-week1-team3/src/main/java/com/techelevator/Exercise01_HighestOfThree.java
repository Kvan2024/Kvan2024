package com.techelevator;

public class Exercise01_HighestOfThree {

    /*
     Given three integer values, return the highest value.

     Note: a value may be considered higher if it is greater than or equal to the other value.

     highestOfThree(1, 3, 2) → 3
     highestOfThree(77, 45, 19) → 77
     highestOfThree(-119, 35, 102) → 102
     highestOfThree(63, 63, 63) → 63
     */
    public int highestOfThree(int a, int b, int c) {

        if (a >= b && a >= c) {
            return a;
        }
        else if (b >= a && b >= c) {
            return b;
        }
        else {
            return c;
        }
    }
}
