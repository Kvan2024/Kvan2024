package com.techelevator;

import java.util.ArrayList;
import java.util.List;

public class Exercise01 {

    /*
    Given a List of Strings, return a List of the Strings that don't start with a vowel (A, E, I, O, U).
    Keep in mind case sensitivity, the first letter may be lowercase.

    Examples:
    noStartingVowels( {"Tooth", "Easy", "Mirror"} )  ->  {"Tooth", "Mirror"}
    noStartingVowels( {"red", "green", "orange"} )  ->  {"red", "green"}
    noStartingVowels( {"Call", "Bill", "about", "the", "Elephant"} )  ->  {"Call", "Bill", "the"}
	 */
    public List<String> noStartingVowels(List<String> inputValues) {


        return new ArrayList<>();
    }
}
