package com.techelevator;

import java.util.ArrayList;
import java.util.List;

public class Exercise02 {

    /*
    Given a List, return a new List with the "odd" indexes first, then the "even" indexes.
    In other words, if given a list with 7 elements (index 0-6),
    return a List in the order of 1, 3, 5, 0, 2, 4, 6.

    Examples:
    shuffleList( {"Tooth", "Easy", "Mirror"} )  ->  {"Easy", "Tooth", "Mirror"}
    shuffleList( {"Apple", "Banana", "Coconut", "Donut", "Egg", "Flour"} )  ->  {"Banana", "Donut", "Flour", "Apple", "Coconut", "Egg"}
    shuffleList( {"Call", "Bill", "about", "the", "Elephant"} )  ->  {"Bill", "the", "Call", "about", "Elephant"}
    */
    public List<String> shuffleList(List<String> inputValues) {


        return new ArrayList<>();
    }
}
