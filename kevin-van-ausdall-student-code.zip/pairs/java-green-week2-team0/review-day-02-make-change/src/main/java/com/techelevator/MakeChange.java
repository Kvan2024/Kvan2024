package com.techelevator;

import java.util.Scanner;

public class MakeChange {
	/*
	Write a command line program which prompts the user for the total bill, and the amount tendered. It should then display the change required.
	
	C:\Users> MakeChange
	
	Please enter the amount of the bill: 23.65
	Please enter the amount tendered: 100.00
	The change required is 76.35
	*/
	public static void main(String[] args) {
		double amountOfBill;
		double amountTendered;

		Scanner userInput = new Scanner(System.in);
		System.out.println("Please enter the amount of the bill: ");
		amountOfBill = userInput.nextDouble();
		System.out.println("Please enter the amount tendered: ");
		amountTendered = userInput.nextDouble();

		String changeDue = String.valueOf(amountTendered - amountOfBill);
		System.out.println("Change required is " + changeDue);

	}

}
